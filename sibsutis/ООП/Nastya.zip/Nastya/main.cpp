#include "src.h"

int main(void)
{
	Game curGame;

	curGame.StartGame();

	return 0;
}
