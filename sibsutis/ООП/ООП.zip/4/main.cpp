#include <iostream>

using namespace std;

void Function (int	a, int b) 		{ cout << "(int, int) Function" << endl; }
void Function (float a, float b) 	{ cout << "(float, float) FirstFunction" << endl; }
void Function (double a, float b) 	{ cout << "(double, float) FirstFunction" << endl; }
void Function (char a, double b) 	{ cout << "(char, double) FirstFunction" << endl; }
void Function (bool a, bool b) 		{ cout << "(bool, bool) FirstFunction" << endl; }

template <typename T> void StrPrint(T str) {
	cout << str << endl;
} 

template<> void StrPrint<int> (int i){
	cout << "For INT only - " << i << endl;
}

int main(void)
{
	Function(1, 5);
	StrPrint("Hello world");
	StrPrint(123213.0f);
	StrPrint(123);
	return 0;
}
