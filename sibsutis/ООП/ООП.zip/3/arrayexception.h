#ifndef ARRAYEXCEPTION_H
#define ARRAYEXCEPTION_H

class ArrayException
{
public:
	ArrayException(){}
};

#endif // ARRAYEXCEPTION_H
