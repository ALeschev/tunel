#include "src/game.h"

int main(void)
{
	Game *newGame = new Game();

	newGame->StartGame();

	return 0;
}